function Stuff() {
    return(
        <div className="container">
          <div className="child "></div>
          <div className="parent">
              <div className="child"></div>
              <div className="child"></div>
          </div>
          <div className="child"></div>
          <div className="parent">
              <div className="child"></div>
              <div className="child"></div>
              <div className="child"></div>
          </div>
      </div>
    );
}
export default Stuff;